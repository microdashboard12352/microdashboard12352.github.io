const $ = (s) => document.querySelector(s);

const tokenInput = $("#token");
tokenInput.value = localStorage.getItem("microhax_dashboard_token") || "";
tokenInput.addEventListener("input", () => {
  localStorage.setItem("microhax_dashboard_token", tokenInput.value);
});

function authHeaders(extra = {}) {
  const token = tokenInput.value.trim();
  return token
    ? {...extra, Authorization: `Bearer ${token}`}
    : extra;
}

async function adminPost(url, body) {
  const response = await fetch(url, {
    method: "POST",
    headers: authHeaders({"Content-Type":"application/json"}),
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  $("#adminResult").textContent =
    response.ok ? JSON.stringify(data, null, 2) : `ERROR ${response.status}\n${JSON.stringify(data,null,2)}`;
  return data;
}

async function announceRoom() {
  await adminPost("/api/admin/announce", {
    message: $("#announceText").value
  });
}

async function kickPlayer() {
  await adminPost("/api/admin/kick", {
    id: Number($("#modId").value),
    reason: $("#modReason").value
  });
}

async function banPlayer() {
  await adminPost("/api/admin/ban", {
    id: Number($("#modId").value),
    reason: $("#modReason").value
  });
}

async function changeMap() {
  await adminPost("/api/admin/map", {
    map: $("#mapName").value
  });
}

async function saveRoom() {
  await adminPost("/api/admin/save", {});
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, m => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[m]));
}

function renderPlayers(list, target) {
  $(target).innerHTML = (list || []).length
    ? list.map(p => `
      <div class="player">
        <span>${esc(p.name)}</span>
        <span class="meta">#${p.id} • ${esc(p.role)} • ${p.elo} ELO</span>
      </div>
    `).join("")
    : '<div class="meta">None</div>';
}

function render(state) {
  const online = state.status === "online";
  $("#status").textContent = online ? "ONLINE" : "OFFLINE";
  $("#status").className = `status ${online ? "online" : "offline"}`;
  $("#players").textContent = `${state.room.players}/${state.room.maxPlayers}`;
  $("#map").textContent = String(state.room.map || "—").toUpperCase();

  if (state.room.link) {
    $("#roomLink").href = state.room.link;
  }

  const mode = state.pub?.mode
    ? `${state.pub.mode}v${state.pub.mode}`
    : "PUB";
  $("#mode").textContent = mode;
  $("#db").textContent = state.database.postgres ? "PostgreSQL" : "JSON";
  $("#phase").textContent = String(state.pub?.phase || "WAITING").toUpperCase();
  $("#pickState").textContent =
    state.pick.active ? `TURN ${state.pick.turn}` : "READY";

  renderPlayers(state.teams.red, "#red");
  renderPlayers(state.teams.blue, "#blue");
  renderPlayers(state.teams.spectators, "#spec");

  $("#pubInfo").innerHTML = `
    <strong>Round:</strong> ${state.pub?.round || 0}<br>
    <strong>Mode:</strong> ${esc(mode)}<br>
    <strong>Phase:</strong> ${esc(state.pub?.phase || "waiting")}
  `;

  $("#pickInfo").innerHTML = `
    <strong>Active:</strong> ${state.pick.active ? "YES" : "NO"}<br>
    <strong>Selected:</strong> ${state.pick.selected?.length || 0}<br>
    <strong>Captains:</strong> ${(state.pick.captains || []).join(", ") || "—"}
  `;

  $("#ranking").innerHTML =
    (state.ranking || []).map((p, i) => `
      <tr>
        <td>${i + 1}</td>
        <td>${esc(p.name)}</td>
        <td>${esc(p.role)}</td>
        <td><strong>${p.elo}</strong></td>
        <td>${p.level}</td>
        <td>${p.wins}</td>
        <td>${p.losses}</td>
      </tr>
    `).join("");

  $("#matches").innerHTML =
    (state.matches || []).length
      ? state.matches.map(m => `
        <div class="match">
          <span>${esc(m.map || "map")}</span>
          <strong>${m.red ?? 0} - ${m.blue ?? 0}</strong>
          <span>${m.winner === 1 ? "RED" : m.winner === 2 ? "BLUE" : "DRAW"}</span>
        </div>
      `).join("")
      : '<div class="meta">No matches yet.</div>';
}

async function initialLoad() {
  const r = await fetch("/api/state");
  render(await r.json());
}

function connectWS() {
  const protocol = location.protocol === "https:" ? "wss:" : "ws:";
  const ws = new WebSocket(`${protocol}//${location.host}/ws`);
  ws.onmessage = e => {
    try {
      const msg = JSON.parse(e.data);
      if (msg.type === "state") render(msg.data);
    } catch {}
  };
  ws.onclose = () => setTimeout(connectWS, 2000);
}

initialLoad();
connectWS();
